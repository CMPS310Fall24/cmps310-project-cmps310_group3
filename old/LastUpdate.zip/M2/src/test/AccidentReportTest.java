package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.AccidentReport;
import model.Vehicle;
import model.Country;

import java.time.LocalDate;

public class AccidentReportTest {
    private AccidentReport report;
    private Vehicle victim;
    private Vehicle offender;

    @BeforeEach
    public void setUp() {
        victim = new Vehicle(1001, Country.QATAR, "Toyota Corolla", 2020, false, 0, 12345, null, null, null, null);
        offender = new Vehicle(1002, Country.JAPAN, "Nissan Altima", 2019, true, 1, 67890, null, null, null, null);
        report = new AccidentReport(LocalDate.of(2024, 11, 20), victim, offender);
    }

    @Test
    public void testGetters() {
        assertEquals(100, report.getCaseNum()); 
        assertEquals(LocalDate.of(2024, 11, 20), report.getIssueDate());
        assertEquals(victim, report.getVictim());
        assertEquals(offender, report.getOffender());
    }

    @Test
    public void testSetters() {
        report.setCaseNum(101);
        report.setIssueDate(LocalDate.of(2025, 1, 1));

        assertEquals(101, report.getCaseNum());
        assertEquals(LocalDate.of(2025, 1, 1), report.getIssueDate());
    }
}
