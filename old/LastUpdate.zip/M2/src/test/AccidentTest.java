package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Accident;

import java.time.LocalDate;
import java.time.LocalTime;

public class AccidentTest {
    private Accident accident;

    @BeforeEach
    public void setUp() {
        accident = new Accident(LocalDate.of(2024, 11, 20), LocalTime.of(15, 30), "Doha", "Rear-end collision");
    }

    @Test
    public void testGetters() {
        assertEquals(LocalDate.of(2024, 11, 20), accident.getDate());
        assertEquals(LocalTime.of(15, 30), accident.getTime());
        assertEquals("Doha", accident.getLocation());
        assertEquals("Rear-end collision", accident.getDescription());
    }

    @Test
    public void testSetters() {
        accident.setDate(LocalDate.of(2025, 1, 1));
        accident.setTime(LocalTime.of(10, 0));
        accident.setLocation("Al Wakrah");
        accident.setDescription("Side collision");

        assertEquals(LocalDate.of(2025, 1, 1), accident.getDate());
        assertEquals(LocalTime.of(10, 0), accident.getTime());
        assertEquals("Al Wakrah", accident.getLocation());
        assertEquals("Side collision", accident.getDescription());
    }

    @Test
    public void testToString() {
        String expected = "Accident [date=2024-11-20, time=15:30, location=Doha, description=Rear-end collision]";
        assertEquals(expected, accident.toString());
    }
}
