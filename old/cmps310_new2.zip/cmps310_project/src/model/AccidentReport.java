package model;

import java.time.LocalDate;

public class AccidentReport {
	private int caseNum;
	private LocalDate issueDate;
	private LocalDate expiryDate;
	private Vehicle victim;
	private Vehicle offender;
	
	public AccidentReport(int caseNum, LocalDate issueDate, LocalDate expiryDate, Vehicle victim, Vehicle offender) {
		super();
		this.caseNum = caseNum;
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
		this.victim = victim;
		this.offender = offender;
	}

	public int getCaseNum() {
		return caseNum;
	}

	public void setCaseNum(int caseNum) {
		this.caseNum = caseNum;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Vehicle getVictim() {
		return victim;
	}

	public void setVictim(Vehicle victim) {
		this.victim = victim;
	}

	public Vehicle getOffender() {
		return offender;
	}

	public void setOffender(Vehicle offender) {
		this.offender = offender;
	}
	
	public boolean isValid() {
	    LocalDate currentDate = LocalDate.now();
	    if (expiryDate.equals(currentDate)) {
	        return false;
	    }
	    return true;
	}
	
}
