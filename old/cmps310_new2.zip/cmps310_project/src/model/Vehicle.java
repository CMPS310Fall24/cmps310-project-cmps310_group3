package model;

import java.util.ArrayList;
import java.time.LocalDate;

public class Vehicle {
	private int VIN;
	private Country make;
	private String model;
	private int manufactureYear;
	private boolean isImported;
	private int offenceCount;
	//private boolean isVictim;
	//private boolean isOffending;
	private int registrationNum;
	private ArrayList<Invoice> invoices = new ArrayList<Invoice>();
	private Owner currOwner;
	private InsurancePolicy insurance;

	public Vehicle(int vIN, Country make, String model, int manufactureYear, boolean isImported, int offenceCount,
			int registrationNum,Owner currOwner, InsurancePolicy insurance) {
		VIN = vIN;
		this.make = make;
		this.model = model;
		this.manufactureYear = manufactureYear;
		this.isImported = isImported;
		this.offenceCount = offenceCount;
		this.registrationNum = registrationNum;
		this.currOwner = currOwner;
		this.insurance = insurance;
	}

	
	public Owner getCurrOwner() {
		return currOwner;
	}


	public void setCurrOwner(Owner currOwner) {
		this.currOwner = currOwner;
	}


	public InsurancePolicy getInsurance() {
		return insurance;
	}


	public void setInsurance(InsurancePolicy insurance) {
		this.insurance = insurance;
	}


	public int getVIN() {
		return VIN;
	}

	public void setVIN(int vIN) {
		VIN = vIN;
	}

	public Country getMake() {
		return make;
	}

	public void setMake(Country make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getManufactureYear() {
		return manufactureYear;
	}

	public void setManufactureYear(int manufactureYear) {
		this.manufactureYear = manufactureYear;
	}

	public boolean isImported() {
		return isImported;
	}

	public void setImported(boolean isImported) {
		this.isImported = isImported;
	}

	public int getOffenceCount() {
		return offenceCount;
	}

	public void setOffenceCount(int offenceCount) {
		this.offenceCount = offenceCount;
	}

//	public boolean isVictim() {
//		return isVictim;
//	}
//
//	public void setVictim(boolean isVictim) {
//		this.isVictim = isVictim;
//	}

	public int getRegistrationNum() {
		return registrationNum;
	}

	public void setRegistrationNum(int registrationNum) {
		this.registrationNum = registrationNum;
	}

//	public boolean isOffending() {
//		return isOffending;
//	}
//
//	public void setOffending(boolean isOffending) {
//		this.isOffending = isOffending;
//	}

	public boolean isOverTwoYearsOld() {
		LocalDate currentDate = LocalDate.now();
		int year = currentDate.getYear();
		if (year - manufactureYear >= 2) {
			return true;
		}
		return false;
	}

	// isImported(boolean isImported) - > get isImported()
	// assignRegistrationNum() - > setRegistrationNum

	public void updateOnwer(Owner newOnwer) {
		currOwner = newOnwer;
	}

//	public void assignOffendingVehicle_victimVehicle() { // we changed the name
//		
//	} --> they are in the accident report class

	public double totalInvoices() {
		double total = 0;

		for (Invoice invoice : invoices) {
			total += invoice.getAmount();
		}
		return total;
	}

}
