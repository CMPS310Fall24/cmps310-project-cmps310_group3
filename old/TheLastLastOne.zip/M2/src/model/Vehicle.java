package model;

import java.util.ArrayList;
import java.time.LocalDate;

public class Vehicle {
	private int VIN;
	private Country make;
	private String model;
	private int manufactureYear;
	private boolean isImported;
	private int offenceCount;
	private int registrationNum;
	private ArrayList<Invoice> invoices = new ArrayList<Invoice>();
	private Owner currOwner;
	private InsurancePolicy insurance;
	private FitnessCertificate certificate;
	private RegistrationSticker sticker;
	

	public Vehicle(int vIN, Country make, String model, int manufactureYear, boolean isImported, int offenceCount,
			int registrationNum,Owner currOwner, InsurancePolicy insurance, FitnessCertificate certificate, RegistrationSticker sticker) {
		VIN = vIN;
		this.make = make;
		this.model = model;
		this.manufactureYear = manufactureYear;
		this.isImported = isImported;
		this.offenceCount = offenceCount;
		this.registrationNum = registrationNum;
		this.currOwner = currOwner;
		this.insurance = insurance;
		this.certificate = certificate;
		this.sticker = sticker;
	}

	
	public Owner getCurrOwner() {
		return currOwner;
	}


	public void setCurrOwner(Owner currOwner) {
		this.currOwner = currOwner;
	}


	public InsurancePolicy getInsurance() {
		return insurance;
	}


	public void setInsurance(InsurancePolicy insurance) {
		this.insurance = insurance;
	}


	public int getVIN() {
		return VIN;
	}

	public void setVIN(int vIN) {
		VIN = vIN;
	}

	public Country getMake() {
		return make;
	}

	public void setMake(Country make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getManufactureYear() {
		return manufactureYear;
	}

	public void setManufactureYear(int manufactureYear) {
		this.manufactureYear = manufactureYear;
	}

	public boolean isImported() {
		return isImported;
	}

	public void setImported(boolean isImported) {
		this.isImported = isImported;
	}

	public int getOffenceCount() {
		return offenceCount;
	}

	public void setOffenceCount(int offenceCount) {
		this.offenceCount = offenceCount;
	}



	public int getRegistrationNum() {
		return registrationNum;
	}

	public void setRegistrationNum(int registrationNum) {
		this.registrationNum = registrationNum;
	}
	
	

	public FitnessCertificate getCertificate() {
		return certificate;
	}


	public void setCertificate(FitnessCertificate certificate) {
		this.certificate = certificate;
	}

	

	public RegistrationSticker getSticker() {
		return sticker;
	}


	public void setSticker(RegistrationSticker sticker) {
		this.sticker = sticker;
	}


	public boolean isOverTwoYearsOld() {
		LocalDate currentDate = LocalDate.now();
		int year = currentDate.getYear();
		if (year - manufactureYear >= 2) {
			return true;
		}
		return false;
	}

	public void updateOwner(Owner newOwner) {
		currOwner = newOwner;
	}
	

	public ArrayList<Invoice> getInvoices() {
		return invoices;
	}

	public void setInvoices(ArrayList<Invoice> invoices) {
		this.invoices = invoices;
	}


	public double totalInvoices() {
		double total = 0;

		for (Invoice invoice : invoices) {
			total += invoice.getAmount();
		}
		return total;
	}

	public ArrayList<Invoice> getUnpaidInvoicesUseCase1(){
		ArrayList<Invoice> unpaid = new ArrayList<Invoice>();
		for(Invoice i : invoices) {
			if(i.isPaid()==false && (i.getFeeType().equals(FEETYPE.REGISTRATION)||i.getFeeType().equals(FEETYPE.TRAFFIC_OFFENCE))) {
				unpaid.add(i);
			}
		}
		return unpaid;
	}
	
}
