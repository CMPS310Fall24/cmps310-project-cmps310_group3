package model;


public enum FEETYPE {

	TRANSFER(700.0), REGISTRATION_RENEWAL(500.0), TRAFFIC_OFFENCE(1000.0), REGISTRATION(600.0);

	private final double fee;

	FEETYPE(double d) {
		this.fee = d;
	}

	public double getFee() {
		return fee;
	}
}
