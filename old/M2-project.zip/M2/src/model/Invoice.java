package model;

public class Invoice {

	private double amount;
	private boolean isPaid;
	private FEETYPE feeType;
	
	public Invoice(boolean isPaid, FEETYPE feeType) {
		this.amount = feeType.getFee();
		this.isPaid = isPaid;
		this.feeType = feeType;
	}
	
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public boolean isPaid() {
		return isPaid;
	}
	public void setPaid(boolean isPaid) { 
		this.isPaid = isPaid;
	}
	public FEETYPE getFeeType() {
		return feeType;
	}
	public void setFeeType(FEETYPE feeType) {
		this.feeType = feeType;
	}

	
	@Override
	public String toString() {
		return "Invoice [amount=" + amount + ", isPaid=" + isPaid + ", feeType=" + feeType + "]";
	} 
	
	//public void updateStatus(){} - > setPaid()
	//checkStatus() -> get ispaid()

	
}
