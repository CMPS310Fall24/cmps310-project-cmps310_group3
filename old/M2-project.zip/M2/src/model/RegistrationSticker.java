package model;
import java.time.LocalDate;

public class RegistrationSticker {
	private LocalDate issueDate; 
	private LocalDate expiryDate; 
	private int stickerID;
	private static int nextId = 10000;
	
	public RegistrationSticker(LocalDate issueDate, LocalDate expiryDate) {
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
		this.stickerID = nextId++;
	}
	
	public LocalDate getIssueDate() {
		return issueDate;
	}
	
	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}
	public LocalDate getExpirayDate() {
		return expiryDate;
	}
	public void setExpirayDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getStickerID() {
		return stickerID;
	}
	public void setStickerID(int stickerID) {
		this.stickerID = stickerID;
	}
	
	//public void generateRegistartionSticker()
	
	public boolean isValid() {
	    LocalDate currentDate = LocalDate.now();
	    if (expiryDate.equals(currentDate)) {
	        return false;
	    }
	    return true;
	}
	
	
}


