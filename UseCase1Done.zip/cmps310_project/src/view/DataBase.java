package view;

import java.time.LocalDate;
import java.util.ArrayList;

import model.Country;
import model.FEETYPE;
import model.FitnessCertificate;
import model.InsurancePolicy;
import model.Invoice;
import model.Owner;
import model.RegistrationSticker;
import model.Vehicle;

public class DataBase {
	private  ArrayList<Owner> owners = new ArrayList<Owner>();
	
	public ArrayList<Owner> getOwners() {
		return owners;
	}

	public void setOwners(ArrayList<Owner> owners) {
		this.owners = owners;
	}

	public DataBase() {
		Owner owner1 = new Owner("Ahmed Al-Mansoori", 123456, "55512345", "Doha, Qatar");
        Owner owner2 = new Owner("Fatima Al-Naimi", 234567, "55523456", "Al Rayyan, Qatar");
        Owner owner3 = new Owner("Khalid Al-Thani", 345678, "55534567", "Lusail, Qatar");
        Owner owner4 = new Owner("Maryam Al-Sulaiti", 456789, "55545678", "Al Wakrah, Qatar");
        Owner owner5 = new Owner("Salem Al-Kuwari", 567890, "55556789", "Al Khor, Qatar");
        owners.add(owner1);
        owners.add(owner2);
        owners.add(owner3);
        owners.add(owner4);
        owners.add(owner5);
        
        // Creating InsurancePolicy objects
        InsurancePolicy insurance1 = new InsurancePolicy(101, 5000.0, LocalDate.of(2023, 1, 15), LocalDate.of(2024, 1, 15));
        InsurancePolicy insurance2 = new InsurancePolicy(102, 4500.0, LocalDate.of(2022, 5, 20), LocalDate.of(2023, 5, 20));
        InsurancePolicy insurance3 = new InsurancePolicy(103, 4800.0, LocalDate.of(2023, 3, 10), LocalDate.of(2024, 3, 10));
        InsurancePolicy insurance4 = new InsurancePolicy(104, 5200.0, LocalDate.of(2023, 7, 5), LocalDate.of(2024, 7, 5));
        InsurancePolicy insurance5 = new InsurancePolicy(105, 4700.0, LocalDate.of(2023, 9, 8), LocalDate.of(2024, 9, 8));
        // Creating FitnessCertificate objects
        FitnessCertificate certificate1 = new FitnessCertificate(201, LocalDate.of(2023, 1, 10), LocalDate.of(2024, 1, 10));
        FitnessCertificate certificate2 = new FitnessCertificate(202, LocalDate.of(2022, 5, 15), LocalDate.of(2023, 5, 15));
        FitnessCertificate certificate3 = new FitnessCertificate(203, LocalDate.of(2023, 3, 5), LocalDate.of(2024, 3, 5));
        FitnessCertificate certificate4 = new FitnessCertificate(204, LocalDate.of(2023, 7, 1), LocalDate.of(2024, 7, 1));
        FitnessCertificate certificate5 = new FitnessCertificate(205, LocalDate.of(2023, 9, 3), LocalDate.of(2024, 9, 3));
        
        // RegistrationSticker objects
        RegistrationSticker sticker1 = new RegistrationSticker(LocalDate.of(2023, 1, 15), LocalDate.of(2024, 1, 15));
        RegistrationSticker sticker2 = new RegistrationSticker(LocalDate.of(2022, 5, 10), LocalDate.of(2023, 5, 10));
        RegistrationSticker sticker3 = new RegistrationSticker(LocalDate.of(2023, 6, 20), LocalDate.of(2024, 6, 20));
        RegistrationSticker sticker4 = new RegistrationSticker(LocalDate.of(2021, 9, 5), LocalDate.of(2022, 9, 5));
        RegistrationSticker sticker5 = new RegistrationSticker(LocalDate.of(2023, 3, 12), LocalDate.of(2024, 3, 12));
        
        Vehicle vehicle1 = new Vehicle(1001, Country.QATAR, "Toyota Corolla", 2021, false, 0, 123456, owner1, insurance1, certificate1,sticker1);
        Vehicle vehicle2 = new Vehicle(1002, Country.JAPAN, "Nissan Altima", 2019, true, 1, 789012, owner2, insurance2, certificate2,sticker2);
        Vehicle vehicle3 = new Vehicle(1003, Country.UNITED_STATES, "Ford Mustang", 2022, false, 0, 345678, owner2, insurance3, certificate3,sticker3);
        Vehicle vehicle4 = new Vehicle(1004, Country.GERMANY, "BMW X5", 2020, true, 2, 901234, owner3, insurance4, certificate4,sticker4);
        Vehicle vehicle5 = new Vehicle(1005, Country.KOREA_SOUTH, "Hyundai Elantra", 2018, false, 3, 567890, owner4, insurance5, certificate5,sticker5);
        
        // Invoice for Vehicle1 
        Invoice invoice1 = new Invoice(true, FEETYPE.REGISTRATION_RENEWAL); 
        // Invoice for Vehicle2 
        Invoice invoice2 = new Invoice(false, FEETYPE.TRANSFER);
        Invoice invoice3 = new Invoice(false, FEETYPE.TRAFFIC_OFFENCE);
        // Invoice for Vehicle3 
        Invoice invoice4 = new Invoice(false, FEETYPE.REGISTRATION);
        // Invoice for Vehicle4 
        Invoice invoice5 = new Invoice(true, FEETYPE.TRANSFER);
        Invoice invoice6 = new Invoice(true, FEETYPE.TRAFFIC_OFFENCE);
        // Invoice for Vehicle5 
        Invoice invoice7 = new Invoice(true, FEETYPE.REGISTRATION_RENEWAL);
        Invoice invoice8 = new Invoice(false, FEETYPE.TRAFFIC_OFFENCE);
        
        vehicle1.getInvoices().add(invoice1);
        vehicle2.getInvoices().add(invoice2);
        vehicle2.getInvoices().add(invoice3);
        vehicle3.getInvoices().add(invoice4);
        vehicle4.getInvoices().add(invoice5);
        vehicle4.getInvoices().add(invoice6);
        vehicle5.getInvoices().add(invoice7);
        vehicle5.getInvoices().add(invoice8);
        
        owner1.getVehicles().add(vehicle1);
        owner2.getVehicles().add(vehicle2);
        owner3.getVehicles().add(vehicle3);
        owner4.getVehicles().add(vehicle4);
        owner5.getVehicles().add(vehicle5);
        
   
	}
}
