package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
 
public class MainMenu extends JFrame {
	DataBase DB = new DataBase();
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
 
	/**
	 * Launch the application.
	 */
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu frame = new MainMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
 


	/**
	 * Create the frame.
	 */
	public MainMenu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
 
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JLabel selection = new JLabel("Select choice: ");
		selection.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
		selection.setBounds(62, 100, 139, 21);
		contentPane.add(selection);
		String[] options = {"Click for choice","Transfer Registered Vehicle", "Manage Accident"};
		JComboBox<String> choiceBox = new JComboBox<String>(options);
		choiceBox.setBounds(193, 100, 209, 27);
		contentPane.add(choiceBox);
		JButton next = new JButton("Next");
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(choiceBox.getEditor().getItem().equals("Click for choice")) {
					JOptionPane.showMessageDialog(null, "Please choose an option");
				}
				else if(choiceBox.getEditor().getItem().equals("Transfer Registered Vehicle")) {
					TransferRegisteredVehicle op1 = new TransferRegisteredVehicle(DB);
					dispose();
					op1.setVisible(true);
				}
				else if(choiceBox.getEditor().getItem().equals(("Manage Accident"))) {
					ManageAccident op2 = new ManageAccident(DB);
					dispose();
					op2.setVisible(true);
				}			
				
				else {
					contentPane.setVisible(false);
				}
			}
		});
		next.setBounds(72, 163, 117, 46);
		contentPane.add(next);
		
		JButton exitButton = new JButton("Exit");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//exit
				dispose();                
			}
		});
		exitButton.setBounds(243, 163, 117, 46);
		contentPane.add(exitButton);
	}
}
