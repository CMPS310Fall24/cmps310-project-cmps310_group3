package view;

import java.time.LocalDate;
import java.util.ArrayList;

import model.RegistrationSticker;
//delete later
public class Try {
	public static void main(String[]args){
		 RegistrationSticker sticker1 = new RegistrationSticker(LocalDate.of(2023, 1, 15), LocalDate.of(2024, 1, 15));
	     RegistrationSticker sticker2 = new RegistrationSticker(LocalDate.of(2022, 5, 10), LocalDate.of(2023, 5, 10));
	     
	     System.out.println(sticker1.getStickerID());
	     System.out.println(sticker2.getStickerID());
	     
	     
		
	}
}
