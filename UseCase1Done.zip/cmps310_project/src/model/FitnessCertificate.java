package model;

import java.time.LocalDate;

public class FitnessCertificate {
	private int certificateNum;
	private LocalDate issueDate; 
	private LocalDate expiryDate;
	
	
	public FitnessCertificate(int certificateNum, LocalDate issueDate, LocalDate expiryDate) {
		super();
		this.certificateNum = certificateNum;
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
	}
	
	
	public int getCertificateNum() {
		return certificateNum;
	}
	public void setCertificateNum(int certificateNum) {
		this.certificateNum = certificateNum;
	}
	public LocalDate getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	public boolean isValid() {
	    LocalDate currentDate = LocalDate.now();
	    if (expiryDate.equals(currentDate)) {
	        return false;
	    }
	    return true;
	}
	
	
}
