package model;

import java.time.LocalDate;

public class AccidentReport {
	private int caseNum;
	private static int nextCaseNum = 100;
	private LocalDate issueDate;
	//private LocalDate expiryDate;
	private Vehicle victim;
	private Vehicle offender;
	
	public AccidentReport(LocalDate issueDate, Vehicle victim, Vehicle offender) {
		this.caseNum = nextCaseNum++;
		this.issueDate = issueDate;
		//this.expiryDate = expiryDate;
		this.victim = victim;
		this.offender = offender;
		
	}

	public int getCaseNum() {
		return caseNum;
	}

	public void setCaseNum(int caseNum) {
		this.caseNum = caseNum;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}


	public Vehicle getVictim() {
		return victim;
	}

	public void setVictim(Vehicle victim) {
		this.victim = victim;
	}

	public Vehicle getOffender() {
		return offender;
	}

	public void setOffender(Vehicle offender) {
		this.offender = offender;
	}
//	
//	public boolean isValid() {
//	    LocalDate currentDate = LocalDate.now();
//	    if (expiryDate.equals(currentDate)) {
//	        return false;
//	    }
//	    return true;
//	}
	
}
