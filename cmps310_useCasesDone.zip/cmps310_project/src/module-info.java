/**
 * 
 */
/**
 * @author shaikha
 *
 */
module cmps310_project {
	requires java.desktop;
}