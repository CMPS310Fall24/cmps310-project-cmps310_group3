package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.Owner;
import model.Vehicle;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

public class ManageAccident extends JFrame {

	private JPanel contentPane;
	private JTextField VIN1txt;
	private JTextField VIN2txt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageAccident frame = new ManageAccident(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageAccident(DataBase DB) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);

		JLabel required = new JLabel("Please enter the VINs of the vehicles involoved: ");
		required.setBounds(64, 55, 331, 16);
		getContentPane().add(required);

		JLabel VIN1lable = new JLabel("your VIN:");
		VIN1lable.setBounds(36, 105, 61, 16);
		getContentPane().add(VIN1lable);

		VIN1txt = new JTextField();
		VIN1txt.setBounds(177, 100, 130, 26);
		getContentPane().add(VIN1txt);
		VIN1txt.setColumns(10);

		JLabel VIN2lable = new JLabel("the victim's VIN:");
		VIN2lable.setBounds(36, 152, 129, 16);
		getContentPane().add(VIN2lable);

		VIN2txt = new JTextField();
		VIN2txt.setBounds(177, 147, 130, 26);
		getContentPane().add(VIN2txt);
		VIN2txt.setColumns(10);

		JButton nextBtn = new JButton("Next");
		nextBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Retrieve vehicles info
	

				Vehicle offender = null;
				Vehicle victim = null;
				for (Owner o : DB.getOwners()) {
					for (Vehicle v : o.getVehicles()) {

						if (v.getVIN() == Integer.parseInt(VIN1txt.getText())) {
							offender = v;
						}  
						
						if (v.getVIN() == Integer.parseInt(VIN2txt.getText())) {
							victim = v;
						} 
					}
				}
				
				if (VIN1txt.getText().equals(VIN2txt.getText())) {
					JOptionPane.showMessageDialog(null, "You have entered the same VIN");
				
				} else if (offender == null || victim == null) {
					JOptionPane.showMessageDialog(null, "Incorrect information!");
					dispose();
					
				} else {
					AccidentDetails AD = new AccidentDetails(DB, victim,offender);
					AD.setVisible(true);
				}
			
			}

		});

		nextBtn.setBounds(64, 217, 117, 29);
		getContentPane().add(nextBtn);

		JButton exitBtn = new JButton("Exit");
		exitBtn.setBounds(260, 217, 117, 29);

		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// exit
				dispose();
			}
		});
		getContentPane().add(exitBtn);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

	}
}
