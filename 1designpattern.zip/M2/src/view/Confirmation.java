package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Accident;
import model.Vehicle;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JButton;
import model.InsurancePolicy;
import model.InsurancePolicy;
import model.AccidentReport;
import model.DataBaseSingleObject;


public class Confirmation extends JFrame {
	public Confirmation(DataBaseSingleObject DB, Vehicle victim, Vehicle offender, Accident accident) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Do you confirm the previous accident information?");
		lblNewLabel.setBounds(61, 103, 328, 16);
		getContentPane().add(lblNewLabel);
		
		JButton confirmBtn = new JButton("Confirm");
		confirmBtn.setBounds(58, 154, 117, 29);
		getContentPane().add(confirmBtn);
		
		confirmBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// record confirmation 
				DB.getConfirmedAccident().add(accident);
				InsurancePolicy victimIP = victim.getInsurance();
				InsurancePolicy offenderIP = offender.getInsurance();
	
				// create an accident report
				LocalDate issueDate = LocalDate.now();
				LocalDate expiryDate = issueDate.plusYears(1);
				AccidentReport accidentReport= new AccidentReport(issueDate,victim,offender);
				DB.getReports().add(accidentReport);
	
				
				JOptionPane.showMessageDialog(null, "The accident is confirmed, and an accident report was created successfully!" +
				"and it will be sent to the insurance company.");

			}});
		
		JButton noBtn = new JButton("Go Back");
		noBtn.setBounds(232, 154, 117, 29);
		getContentPane().add(noBtn);
		
		noBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageAccident ma=new ManageAccident(DB);
				ma.setVisible(true);
			}});
		
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Confirmation frame = new Confirmation(null, null, null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
