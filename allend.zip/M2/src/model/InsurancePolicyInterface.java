package model;

import java.time.LocalDate;

public interface InsurancePolicyInterface {

	public int getPolicyNum();

	public double getPolicyAmount();

	public LocalDate getIssueDate();

	public LocalDate getExpiryDate();

	public boolean isValid();

}
