package model;

import java.util.ArrayList;

public class OwnerProxy implements OwnerInterface {
	private Owner realOwner;

	public OwnerProxy(String name, int QID, String phoneNum, String address) {
		this.realOwner = new Owner(name, QID, phoneNum, address);

	}

	@Override
	public String getName() {
		return realOwner.getName();
	}

	@Override
	public String getPhoneNum() {
		return realOwner.getPhoneNum();
	}

	@Override
	public String getAddress() {
		return realOwner.getAddress();
	}

	@Override
	public ArrayList<CreditCardProxy> getCreditCards() {
		return realOwner.getCreditCards();
	}

	@Override
	public ArrayList<Vehicle> getVehicles() {
		return realOwner.getVehicles();
	}

	@Override
	public void addCreditCard(CreditCardProxy creditCard) {
		realOwner.addCreditCard(creditCard);
	}

	@Override
	public String toString() {
		return "OwnerProxy [name=" + realOwner.getName() + ", phoneNum=" + realOwner.getPhoneNum() + ", address="
				+ realOwner.getAddress() + "]";
	}

	@Override
	public void setQID(int QID) {
		realOwner.setQID(QID);
		
	}

	@Override
	public int getQID() {
		return realOwner.getQID();
	}

}
