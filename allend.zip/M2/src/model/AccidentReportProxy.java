package model;

import java.time.LocalDate;

public class AccidentReportProxy implements AccidentReportInterface {

	private AccidentReport realReport;

	public AccidentReportProxy(LocalDate issueDate, Vehicle victim, Vehicle offender) {
		this.realReport = new AccidentReport(issueDate, victim, offender);
	}

	@Override
	public int getCaseNum() {
			return realReport.getCaseNum();
	}

	@Override
	public void setCaseNum(int caseNum) {
			realReport.setCaseNum(caseNum);
	}

	@Override
	public Vehicle getVictim() {
			return realReport.getVictim();
	}

	@Override
	public void setVictim(Vehicle victim) {
			realReport.setVictim(victim);
	}

	@Override
	public Vehicle getOffender() {
			return realReport.getOffender();
	}

	@Override
	public void setOffender(Vehicle offender) {
			realReport.setOffender(offender);
	}

}
