package model;

import java.util.ArrayList;

public interface OwnerInterface {

	public String getName();

	public String getPhoneNum();

	public String getAddress();

	public ArrayList<CreditCardProxy> getCreditCards();

	public ArrayList<Vehicle> getVehicles();

	public void addCreditCard(CreditCardProxy creditCard);

	public void setQID(int QID);

	public int getQID();

}
