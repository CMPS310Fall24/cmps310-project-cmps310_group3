package model;

public interface CreditCardInterface {

	public int getCardNum();

	public void setCardNum(int cardNum);

	public String getCardHolderName();

	public void setCardHolderName(String cardHolderName);

	public boolean isValid();

	public void setValid(boolean isValid);

}
