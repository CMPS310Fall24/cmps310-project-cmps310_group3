package model;

import java.time.LocalDate;

public class FitnessCertificateProxy implements FitnessCertificateInterface{
	    private FitnessCertificate realCertificate;
	    
	    public FitnessCertificateProxy(int certificateNum, LocalDate issueDate, LocalDate expiryDate) {
	        this.realCertificate = new FitnessCertificate(certificateNum,issueDate,expiryDate);
	    }

	    @Override
	    public int getCertificateNum() {
	            return realCertificate.getCertificateNum();
	    }

	    @Override
	    public LocalDate getIssueDate() {
	        return realCertificate.getIssueDate();
	    }

	    @Override
	    public LocalDate getExpiryDate() {
	        return realCertificate.getExpiryDate();
	    }

	    @Override
	    public boolean isValid() {
	        return realCertificate.isValid();
	    }
	

}
