package model;

import java.util.ArrayList;

public class Owner implements OwnerInterface{

	private String name;
	private int QID;
	private String phoneNum;
	private String address; 
	private ArrayList <CreditCardProxy> creditCards=new ArrayList <CreditCardProxy>(); 
	private ArrayList <Vehicle> vehicles=new ArrayList <Vehicle>(); 
	
	
	public Owner(String name, int QID, String phoneNum, String address) {
		this.name = name;
		this.QID = QID;
		this.phoneNum = phoneNum;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQID() {
		return QID;
	}

	public void setQID(int QID) {
		this.QID = QID;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	

	public ArrayList<CreditCardProxy> getCreditCards() {
		return creditCards;
	}

	public void setCreditCards(ArrayList<CreditCardProxy> creditCards) {
		this.creditCards = creditCards;
	}

	public ArrayList<Vehicle> getVehicles() {
		return vehicles;
	}

    public void addCreditCard(CreditCardProxy creditCard) {
    	creditCards.add(creditCard);
    }

	
	@Override
	public String toString() {
		return "Owner [name=" + name + ", QID=" + QID + ", phoneNum=" + phoneNum + ", address=" + address
				+ "]";
	
	}
	
	
}

