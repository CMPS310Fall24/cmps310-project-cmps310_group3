package model;

import java.time.LocalDate;

public interface FitnessCertificateInterface {

	public int getCertificateNum();

	public LocalDate getIssueDate();

	public LocalDate getExpiryDate();

	public boolean isValid();

}
