package model;

import java.time.LocalDate;

public class InsurancePolicyProxy implements InsurancePolicyInterface{
	
	    private InsurancePolicy realPolicy;

	    public InsurancePolicyProxy(int policyNum, double policyAmount, LocalDate issueDate,
				LocalDate expiryDate) {
	        this.realPolicy = new InsurancePolicy(policyNum, policyAmount,issueDate,expiryDate);
	    }

	    @Override
	    public int getPolicyNum() {
	            return realPolicy.getPolicyNum();	       
	    }

	    @Override
	    public double getPolicyAmount() {
	            return realPolicy.getPolicyAmount();
	    }

	    @Override
	    public LocalDate getIssueDate() {
	        return realPolicy.getIssueDate();
	    }

	    @Override
	    public LocalDate getExpiryDate() {
	        return realPolicy.getExpiryDate();
	    }

	    @Override
	    public boolean isValid() {
	        return realPolicy.isValid();
	    }
	

}
