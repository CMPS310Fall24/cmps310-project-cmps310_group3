package model;

import java.time.LocalDate;

public class AccidentReport implements AccidentReportInterface{
	private int caseNum;
	private static int nextCaseNum = 100;
	private LocalDate issueDate;
	private Vehicle victim;
	private Vehicle offender;
	
	public AccidentReport(LocalDate issueDate, Vehicle victim, Vehicle offender) {
		this.caseNum = nextCaseNum++;
		this.issueDate = issueDate;
		this.victim = victim;
		this.offender = offender;
		
	}

	public int getCaseNum() {
		return caseNum;
	}

	public void setCaseNum(int caseNum) {
		this.caseNum = caseNum;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}


	public Vehicle getVictim() {
		return victim;
	}

	public void setVictim(Vehicle victim) {
		this.victim = victim;
	}

	public Vehicle getOffender() {
		return offender;
	}

	public void setOffender(Vehicle offender) {
		this.offender = offender;
	}

	
}
