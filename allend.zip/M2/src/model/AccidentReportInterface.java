package model;

public interface AccidentReportInterface {

	public int getCaseNum();

	public void setCaseNum(int caseNum);

	public Vehicle getVictim();

	public void setVictim(Vehicle victim);

	public Vehicle getOffender();

	public void setOffender(Vehicle offender);

}
