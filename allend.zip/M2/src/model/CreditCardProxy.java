package model;

public class CreditCardProxy implements CreditCardInterface {

	private CreditCard realCreditCard;

	public CreditCardProxy(int cardNum, String cardHolderName, boolean isValid) {
		this.realCreditCard = new CreditCard(cardNum, cardHolderName, isValid);
	}

	@Override
	public int getCardNum() {
		return realCreditCard.getCardNum();
	}

	@Override
	public void setCardNum(int cardNum) {
		realCreditCard.setCardNum(cardNum);
	}

	@Override
	public String getCardHolderName() {
		return realCreditCard.getCardHolderName();
	}

	@Override
	public void setCardHolderName(String cardHolderName) {
		realCreditCard.setCardHolderName(cardHolderName);
	}

	@Override
	public boolean isValid() {
		return realCreditCard.isValid();
	}

	@Override
	public void setValid(boolean isValid) {
		realCreditCard.setValid(isValid);
	}
}
