package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import model.Vehicle;
import model.Owner;
import model.OwnerProxy;
import model.Invoice;
import model.FEETYPE;
import model.Country;

import java.util.ArrayList;

public class VehicleTest {
    private Vehicle vehicle;
    private Invoice unpaidInvoice;
    private Invoice paidInvoice;

    @BeforeEach
    public void setUp() {
        unpaidInvoice = new Invoice(false, FEETYPE.REGISTRATION);
        paidInvoice = new Invoice(true, FEETYPE.TRAFFIC_OFFENCE);
        vehicle = new Vehicle(1001, Country.QATAR, "Toyota Corolla", 2021, false, 0, 12345, null, null, null, null);
        vehicle.getInvoices().add(unpaidInvoice);
        vehicle.getInvoices().add(paidInvoice);
    }

    @Test
    public void testGetUnpaidInvoices() {
        ArrayList<Invoice> unpaidInvoices = vehicle.getUnpaidInvoicesUseCase1();
        assertEquals(1, unpaidInvoices.size());
        assertEquals(unpaidInvoice, unpaidInvoices.get(0));
    }

    @Test
    public void testUpdateOwner() {
        OwnerProxy newOwner = new OwnerProxy("Fatima Al-Naimi", 234567, "55523456", "Al Rayyan, Qatar");
        vehicle.updateOwner(newOwner);
        assertEquals(newOwner, vehicle.getCurrOwner());
    }
}
