package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.DataBaseSingleObject;
import model.FEETYPE;
import model.Invoice;
import model.Owner;
import model.OwnerProxy;
import model.RegistrationSticker;
import model.Vehicle;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

public class NewOwnerInfo extends JFrame {

	private JPanel contentPane;
	private JTextField QIDtxt;
	private JTextField nameTxt;
	private JTextField phoneTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewOwnerInfo frame = new NewOwnerInfo(null, null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewOwnerInfo(DataBaseSingleObject DB, OwnerProxy oldOwner, Vehicle vehicle) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);

		JLabel details = new JLabel("Enter new owner details:");
		details.setBounds(137, 6, 183, 16);
		getContentPane().add(details);

		JLabel QIDlabel = new JLabel("QID");
		QIDlabel.setBounds(93, 58, 61, 16);
		getContentPane().add(QIDlabel);

		JLabel nameLabel = new JLabel("Name");
		nameLabel.setBounds(93, 115, 61, 16);
		getContentPane().add(nameLabel);

		JLabel phoneLabel = new JLabel("Phone Number");
		phoneLabel.setBounds(93, 177, 117, 16);
		getContentPane().add(phoneLabel);

		QIDtxt = new JTextField();
		QIDtxt.setBounds(239, 53, 130, 26);
		getContentPane().add(QIDtxt);
		QIDtxt.setColumns(10);

		nameTxt = new JTextField();
		nameTxt.setBounds(239, 110, 130, 26);
		getContentPane().add(nameTxt);
		nameTxt.setColumns(10);

		phoneTxt = new JTextField();
		phoneTxt.setBounds(239, 172, 130, 26);
		getContentPane().add(phoneTxt);
		phoneTxt.setColumns(10);

		JButton enterButton = new JButton("Enter");
		enterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Validate input fields
				if (QIDtxt.getText().isEmpty() || nameTxt.getText().isEmpty() || phoneTxt.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "All fields must be filled. Please enter valid input.",
							"Input Error", JOptionPane.WARNING_MESSAGE);
					return;
				}

				// Validate phone number format
				String phoneNum = phoneTxt.getText();
				if (!phoneNum.matches("\\d{8}")) {
		            JOptionPane.showMessageDialog(null, "Invalid phone number format. Please enter in the format: (00000000)", "Format Error", JOptionPane.ERROR_MESSAGE);
		            return;
		        }

				// transfer ownership

				// this QID should not be equal 
				int QID = Integer.parseInt(QIDtxt.getText());
				if (oldOwner.getQID()==QID) {
					JOptionPane.showMessageDialog(null, "You must enter a different QID");
					return;
	
				}
				
				String name = nameTxt.getText();
				OwnerProxy newOwner = null;
				for (OwnerProxy o : DB.getOwners()) {
					if (o.getQID() == QID) {
						newOwner = o;
						break;
					} else {
						newOwner = new OwnerProxy(name, QID, phoneNum, null);
					}
				}

				vehicle.updateOwner(newOwner);
				DB.getOwners().add(newOwner);
				newOwner.getVehicles().add(vehicle);

				for (Vehicle v : oldOwner.getVehicles()) {
					if (vehicle.getVIN() == v.getVIN()) {
						oldOwner.getVehicles().remove(v);
						break;
					}
				}

				// generate Registration Sticker
				LocalDate issueDate = LocalDate.now();
				LocalDate expiryDate = issueDate.plusYears(1);
				RegistrationSticker sticker = new RegistrationSticker(issueDate, expiryDate);
				vehicle.setSticker(sticker);

				// create invoice
				Invoice invoice = new Invoice(false, FEETYPE.TRANSFER);
				vehicle.getInvoices().add(invoice);

				JOptionPane.showMessageDialog(null, "Ownership was transfered successfully!");
				dispose();
			}
		});
		enterButton.setBounds(48, 216, 117, 29);
		getContentPane().add(enterButton);

		JButton exitButton = new JButton("Exit");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// exit
				dispose();
			}
		});
		exitButton.setBounds(272, 216, 117, 29);
		getContentPane().add(exitButton);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

	}
}
