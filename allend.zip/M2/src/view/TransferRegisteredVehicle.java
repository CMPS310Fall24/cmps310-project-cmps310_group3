package view;

import java.awt.EventQueue;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.DataBaseSingleObject;
import model.Owner;
import model.OwnerProxy;
import model.Vehicle;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

public class TransferRegisteredVehicle extends JFrame {
	private JTextField VINtxt;
	private JTextField QIDtxt;
	private JTextField ownerTxt;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TransferRegisteredVehicle frame = new TransferRegisteredVehicle(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TransferRegisteredVehicle(DataBaseSingleObject DB) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().setLayout(null);

		JLabel required = new JLabel("Please fill the following:");
		required.setBounds(144, 18, 151, 16);
		getContentPane().add(required);

		JLabel VINlabel = new JLabel("VIN:");
		VINlabel.setBounds(45, 73, 61, 16);
		getContentPane().add(VINlabel);

		JLabel QIDlabel = new JLabel("QID:");
		QIDlabel.setBounds(45, 125, 61, 16);
		getContentPane().add(QIDlabel);

		JLabel ownerLabel = new JLabel("Current Owner Name:");
		ownerLabel.setBounds(45, 166, 189, 42);
		getContentPane().add(ownerLabel);

		VINtxt = new JTextField();
		VINtxt.setBounds(221, 68, 130, 26);
		getContentPane().add(VINtxt);
		VINtxt.setColumns(10);

		QIDtxt = new JTextField();
		QIDtxt.setBounds(221, 120, 130, 26);
		getContentPane().add(QIDtxt);
		QIDtxt.setColumns(10);

		ownerTxt = new JTextField();
		ownerTxt.setBounds(221, 174, 130, 26);
		getContentPane().add(ownerTxt);
		ownerTxt.setColumns(10);

		JButton exitButton = new JButton("Exit");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// exit
				dispose();
			}
		});
		exitButton.setBounds(242, 212, 117, 29);
		getContentPane().add(exitButton);

		JButton nextButton = new JButton("Next");
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double startTime = System.nanoTime();
				//retrieve info
				 if (VINtxt.getText().trim().isEmpty() || QIDtxt.getText().trim().isEmpty() || ownerTxt.getText().trim().isEmpty()) {
			            JOptionPane.showMessageDialog(null, "All fields must be filled. Please check your input.", "Input Error", JOptionPane.WARNING_MESSAGE);
			            return;
			        }
				 OwnerProxy oldOwner = null;
				Vehicle vehicle = null;

				for (OwnerProxy owner : DB.getOwners()) {
					if (owner.getQID() == Integer.parseInt(QIDtxt.getText())) {
						oldOwner = owner;
						break;
					}
				}
				
				
				if (oldOwner == null || !oldOwner.getName().equalsIgnoreCase(ownerTxt.getText())) {
					JOptionPane.showMessageDialog(null,"Wrong Information! Either you have entered a wrong input or you have left a field empty."
							+ "Please recheck.", "Input Error",
							JOptionPane.WARNING_MESSAGE);
					return;
				} else {
					for (Vehicle v : oldOwner.getVehicles()) {
						if (v.getVIN() == Integer.parseInt(VINtxt.getText())) {
							vehicle = v;
							break;
						}
					}

					if (vehicle == null) {

						JOptionPane.showMessageDialog(null,
								"Wrong Information!"
								+ "Either you have entered a wrong input or you have left a field empty."
								+ "Please recheck.", "Input Error",
								JOptionPane.WARNING_MESSAGE);
						return;
					}
				}
				


				//check unpaid invoices
				if (!vehicle.getUnpaidInvoicesUseCase1().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Pay the bills first!");
					dispose();
				} 
				
				//new owner detail
				NewOwnerInfo newOwner = new NewOwnerInfo(DB,oldOwner,vehicle);
				newOwner.setVisible(true);
				
			double endTime = System.nanoTime();
			double time = (endTime-startTime)/1000000000;
			System.out.println(time);
			}
		});
		nextButton.setBounds(57, 212, 117, 29);
		getContentPane().add(nextButton);
	}
}
