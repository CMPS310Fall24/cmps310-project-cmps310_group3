package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.Owner;
import model.Vehicle;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JButton;
import model.Accident;
import model.DataBaseSingleObject;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class AccidentDetails extends JFrame {
	public AccidentDetails(DataBaseSingleObject DB, Vehicle victim, Vehicle offender) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		getContentPane().setLayout(null);

		JLabel request = new JLabel("Please enter the accident detals:");
		request.setBounds(106, 6, 229, 16);
		getContentPane().add(request);

		JLabel dateLable = new JLabel("Date of the accident:");
		dateLable.setBounds(18, 34, 138, 16);
		getContentPane().add(dateLable);

		dateTxt = new JTextField();
		dateTxt.setText("MM/DD/YYYY");
		dateTxt.setBounds(181, 29, 154, 26);
		getContentPane().add(dateTxt);
		dateTxt.setColumns(10);

		JLabel timeLable = new JLabel("Time of the accident:");
		timeLable.setBounds(18, 72, 144, 16);
		getContentPane().add(timeLable);

		timeTxt = new JTextField();
		timeTxt.setText("HH:MM");
		timeTxt.setBounds(181, 67, 154, 26);
		getContentPane().add(timeTxt);
		timeTxt.setColumns(10);

		JLabel locationLable = new JLabel("Location:");
		locationLable.setBounds(17, 109, 84, 16);
		getContentPane().add(locationLable);

		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(181, 105, 130, 27);
		getContentPane().add(comboBox);
		String[] locations = { "Doha", "Al Rayyan", "Al Wakrah", "Al Khor", "Dukhan", "Lusail", "Al Shamal", "Mesaieed",
				"Umm Salal", "Madinat ash Shamal", "Al Daayen", "Al Ruwais", "Simaisma", "Shahaniya" };
		for (int i = 0; i < 14; i++) {
			comboBox.addItem(locations[i]);
		}

		JLabel lblNewLabel = new JLabel("Accident description:");
		lblNewLabel.setBounds(18, 137, 208, 16);
		getContentPane().add(lblNewLabel);

		JTextArea descriptionTxt = new JTextArea();
		descriptionTxt.setBounds(18, 165, 404, 40);
		getContentPane().add(descriptionTxt);

		JButton nextBtn = new JButton("Next");
		nextBtn.setBounds(28, 222, 117, 29);
		getContentPane().add(nextBtn);

		nextBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Record accident info

				DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
				LocalDate date = null; // Declare outside the try block

				try {
					date = LocalDate.parse(dateTxt.getText(), dateFormatter);
				} catch (DateTimeParseException e1) {
				}

				DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
				LocalTime time = null;

				try {
					time = LocalTime.parse(timeTxt.getText(), timeFormatter);
				} catch (DateTimeParseException e1) {
				}

				String location = (String) comboBox.getSelectedItem();
				String description = descriptionTxt.getText();

				if (dateTxt.getText().trim().isEmpty() || timeTxt.getText().trim().isEmpty() || location == null
						|| location.trim().isEmpty() || description.trim().isEmpty()) {

					JOptionPane.showMessageDialog(null,
							"All fields must be filled in. Please do not leave any field empty.", "Input Error",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				Accident accident = new Accident(date, time, location, description);
				Vehicle victim1 = victim;
				Vehicle offender1 = offender;

				if (description.equals("")) {

				}

				Confirmation Confirmation = new Confirmation(DB, victim, offender, accident);
				Confirmation.setVisible(true);

			}

		});

		JButton exitBtn = new JButton("Exit");
		exitBtn.setBounds(273, 222, 117, 29);
		getContentPane().add(exitBtn);
		exitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// exit
				dispose();
			}
		});
	}

	private JPanel contentPane;
	private JTextField dateTxt;
	private JTextField timeTxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccidentDetails frame = new AccidentDetails(null, null, null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
