package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.CreditCard;
import model.Owner;
import model.Vehicle;

public class OwnerTest {
    private Owner owner;

    @BeforeEach
    public void setUp() {
        owner = new Owner("Ahmed Al-Mansoori", 123456, "55512345", "Doha, Qatar");
    }

    @Test
    public void testAddVehicles() {
        Vehicle vehicle = new Vehicle(1001, null, "Toyota Corolla", 2021, false, 0, 12345, owner, null, null, null);
        owner.getVehicles().add(vehicle);
        assertEquals(1, owner.getVehicles().size());
        assertEquals(vehicle, owner.getVehicles().get(0));
    }

    @Test
    public void testAddCreditCard() {
        CreditCard card = new CreditCard(12345678, "Ahmed Al-Mansoori", true);
        owner.getCreditCards().add(card);
        assertEquals(1, owner.getCreditCards().size());
        assertEquals(card, owner.getCreditCards().get(0));
    }
}
