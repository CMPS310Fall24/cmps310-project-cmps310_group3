package model;

import java.time.LocalDate;

public class InsurancePolicy {
	private int policyNum;
	private double policyAmount;
	private LocalDate issueDate; 
	private LocalDate expiryDate;
	
	
	public InsurancePolicy(int policyNum, double policyAmount, LocalDate issueDate,
			LocalDate expiryDate) {
		super();
		this.policyNum = policyNum;
		this.policyAmount = policyAmount;
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
	}

	public int getPolicyNum() {
		return policyNum;
	}

	public void setPolicyNum(int policyNum) {
		this.policyNum = policyNum;
	}


	public double getPolicyAmount() {
		return policyAmount;
	}

	public void setPolicyAmount(double policyAmount) {
		this.policyAmount = policyAmount;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	} 
	
	public boolean isValid() {
	    LocalDate currentDate = LocalDate.now();
	    if (expiryDate.equals(currentDate)) {
	        return false;
	    }
	    return true;
	}
	
}
