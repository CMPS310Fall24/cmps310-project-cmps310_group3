package model;

public class CreditCard {
	private int cardNum;
	private String cardHolderName;
	private boolean isValid;

	public CreditCard(int cardNum, String cardHolderName, boolean isValid) {
		this.cardNum = cardNum;
		this.cardHolderName = cardHolderName;
		this.isValid = isValid;
	}

	public int getCardNum() {
		return cardNum;
	}

	public void setCardNum(int cardNum) {
		this.cardNum = cardNum;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	@Override
	public String toString() {
		return "CreditCard [cardNum=" + cardNum + ", cardHolderName=" + cardHolderName + ", isValid=" + isValid + "]";
	}

}
